# -*- coding: utf-8 -*-
"""report-html-template 自我測試（skill v1.6）。

    python3 tests/run_tests.py

v1.6 是兩條並行分支合併的版本，這支腳本把兩邊的測試併在一起：
  A 回歸 — 六個舊樣張用現在的引擎重建，HTML md5 必須跟 v1.5 定版逐 byte 相同。
          v1.6 的三項新能力（事件線 icon／sig mark: max／sig 底色深淺三階）都是
          「宣告才生效」，舊樣張沒宣告 → 一個 byte 都不該變。
          再加 v1.6 的兩個新樣張 charts-demo-6（icon ＋ mark）與 sig-shade-demo
          （深淺三階）：build 成功、qa_html 17 項全過。
  B 組合 — mark: max（標哪一格）與 scale/levels+v（那一格多深）是正交的兩件事，
          必須能併用：只有較大那格上色、深淺依檢定強度。
  C 負向 — 宣告寫錯時要「報對的錯 ＋ exit 1 ＋ 不寫出 HTML」，不可以默默吞掉。
          19 條＝事件線／mark 那條線 5 條 ＋ 深淺分級那條線 13 條 ＋ 併用 1 條。

全部通過印 [ALL PASS] 並 exit 0；有一項不過就列出來、exit 1。
"""
import hashlib
import io
import os
import re
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SCRIPTS = os.path.join(ROOT, "scripts")
sys.path.insert(0, SCRIPTS)

# v1.5 定版（2026-09-16）的 HTML md5。改引擎預設行為就會變，變了就是改壞了。
BASELINE = {
    "playtime-demo": "71e83fef226ba994fd81f62c0bfb5129",
    "charts-demo": "a08feea5023b54e4b8af833fc74cd33d",
    "charts-demo-2": "60963a3058585c0a0c63518c815041fa",
    "charts-demo-3": "342070f854158fb6664961a29a2090a9",
    "charts-demo-4": "25bff0c5aa7bcc0d320d7517eaec476f",
    # charts-demo-5 是 sig 這段唯一的守門員：v1.5 的單一階底色路徑一變它就會紅
    "charts-demo-5": "49d04f74e7a485e36f0d6e0f31f3a869",
}
JS_MD5 = "79e2d5b43d53764e88de8a6771c64253"    # 互動 JS，從 v1.1 起不准變
CSS_MD5 = "84b3f2cef683bed91dbfe2cfe9b818a0"   # themes.py 的 CSS，從 v1.1 起不准變
THEMES_MD5 = "f62fd318132b25010543040a97d0e27c"  # themes.py 檔案本身，v1.6 零變動
QA_ITEMS = 17                                   # v1.6 新增第 17 項「備註四列」

# 併用組合：在 charts-demo-6（本來只有 mark: max）補上 scale／levels／每組的 v
COMBO = ("""  mark: max
  pairs:
    - {row: 1, a: 2, b: 3}
    - {row: 2, a: 2, b: 3}
    - {row: 3, a: 2, b: 3}""",
         """  mark: max
  scale: "|t|"
  levels: [2.58, 3.29]
  pairs:
    - {row: 1, a: 2, b: 3, v: 5.91}
    - {row: 2, a: 2, b: 3, v: 2.12}
    - {row: 3, a: 2, b: 3, v: 3.04}""")

# 負向案例：把 demo 的內容檔改一行（或幾行）→ 應該報這個錯、exit 1、不產 HTML。
# 每一項都另外要求錯誤訊息帶得出行號（「第 N 行」），Lena 才知道去改哪裡。
NEG = [
    # ---- 事件線 icon ／ sig mark 這條線（5 條）----
    ("vlines 的 icon 打錯", "charts-demo-6",
     [("  - {at: 2026-05-23, label: 跌點 1, color: red, icon: warn}",
       "  - {at: 2026-05-23, label: 跌點 1, color: red, icon: danger}")],
     "vlines 的 icon 只能是 warn"),
    ("vlines 的 color 打錯（v1.4 既有守門，順便回歸）", "charts-demo-6",
     [("  - {at: 2026-05-23, label: 跌點 1, color: red, icon: warn}",
       "  - {at: 2026-05-23, label: 跌點 1, color: green, icon: warn}")],
     "vlines 的 color 只能是 red／ink"),
    ("sig 的 mark 打錯", "charts-demo-6",
     [("  mark: max", "  mark: 最大")],
     "sig 的 mark 只能是 both"),
    ("sig 的 mark: max 但配對的格子不是數字", "charts-demo-6",
     [("每日開局數,3.42,3.05,{{d:-0.37:局}},0.004",
       "每日開局數,N/A,3.05,{{d:-0.37:局}},0.004")],
     "讀不出數字，沒辦法比大小"),
    ("sig 的 a 與 b 指到同一格（v1.5 既有守門，順便回歸）", "charts-demo-6",
     [("    - {row: 1, a: 2, b: 3}", "    - {row: 1, a: 2, b: 2}")],
     "a 與 b 是同一格"),
    # ---- 底色深淺分級這條線（13 條）----
    ("強度值給負數", "sig-shade-demo",
     [("    - {row: 1, a: 2, b: 3, v: 5.91}", "    - {row: 1, a: 2, b: 3, v: -5.91}")],
     "第 1 項的 v 是負的"),
    ("強度值非數字", "sig-shade-demo",
     [("    - {row: 2, a: 2, b: 3, v: 3.04}", "    - {row: 2, a: 2, b: 3, v: 很顯著}")],
     "`v` 要是數字"),
    ("階數超界（三個切點）", "sig-shade-demo",
     [("  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1",
       "  levels: [1.96, 2.58, 3.29]\n  pairs:\n    - {row: 1")],
     "levels 要剛好兩個切點（三階），現在有 3 個"),
    ("只有一個切點", "sig-shade-demo",
     [("  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1",
       "  levels: [2.58]\n  pairs:\n    - {row: 1")],
     "levels 要剛好兩個切點（三階），現在有 1 個"),
    ("切點沒有由小到大", "sig-shade-demo",
     [("  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1",
       "  levels: [3.29, 2.58]\n  pairs:\n    - {row: 1")],
     "levels 要由小到大且不相等"),
    ("切點是負數", "sig-shade-demo",
     [("  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1",
       "  levels: [-1, 3.29]\n  pairs:\n    - {row: 1")],
     "levels 第 1 個 -1 是負的"),
    ("切點非數字", "sig-shade-demo",
     [("  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1",
       "  levels: [p<.01, 3.29]\n  pairs:\n    - {row: 1")],
     "levels 第 1 個 'p<.01' 不是數字"),
    ("有 v 卻沒寫 scale", "sig-shade-demo",
     [('  scale: "|t|"\n  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1',
       "  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1")],
     "sig 缺 `scale`"),
    ("有 v 卻沒寫 levels", "sig-shade-demo",
     [('  scale: "|t|"\n  levels: [2.58, 3.29]\n  pairs:\n    - {row: 1',
       '  scale: "|t|"\n  pairs:\n    - {row: 1')],
     "sig 缺 `levels`"),
    ("只有一部分 pair 帶 v", "sig-shade-demo",
     [("    - {row: 3, a: 2, b: 3, v: 2.12}", "    - {row: 3, a: 2, b: 3}")],
     "第 3 項缺 `v`"),
    ("沒有 v 卻寫了 levels", "sig-shade-demo",
     [('sig:\n  dir: tb\n  scale: "|t|"\n  levels: [2.58, 3.29]\n  pairs:\n'
       "    - {col: 4, a: 3, b: 4, v: 3.12}\n    - {col: 4, a: 5, b: 6, v: 6.41}",
       "sig:\n  dir: tb\n  levels: [2.58, 3.29]\n  pairs:\n"
       "    - {col: 4, a: 3, b: 4}\n    - {col: 4, a: 5, b: 6}")],
     "pairs 都沒有寫 `v`（檢定強度），就不用寫 `levels`"),
    ("備註超過四列（defs 多寫 母體）", "sig-shade-demo",
     [("  著色: 階界 2.58／3.29 ＝大樣本下的 p<.01／p<.001；沒上底色＝未達 p<.05（每局手數 |t| 0.84）",
       "  著色: 階界 2.58／3.29 ＝大樣本下的 p<.01／p<.001；沒上底色＝未達 p<.05（每局手數 |t| 0.84）\n"
       "  母體: 全站活躍玩家，前 31 天／後 30 天")],
     "defs 多了 `母體`——備註只能四列"),
    ("備註多寫一列 口徑", "sig-shade-demo",
     [("  維度: 三個底台（盲注級距）× 前段／後段；同一底台的兩列合併成一群",
       "  維度: 三個底台（盲注級距）× 前段／後段；同一底台的兩列合併成一群\n"
       "  口徑: 斷點當日不計入兩段")],
     "defs 多了 `口徑`——備註只能四列"),
    # ---- 兩條線併用（1 條，v1.6 合併時新增）----
    ("mark: max ＋ v 併用，但某一格不是數字", "charts-demo-6",
     [COMBO, ("平均遊戲時間,43.8,39.1,{{d:-4.7:分}},<0.001@@0.0005",
              "平均遊戲時間,—,39.1,{{d:-4.7:分}},<0.001@@0.0005")],
     "讀不出數字，沒辦法比大小"),
]


def _md5(path):
    return hashlib.md5(io.open(path, "rb").read()).hexdigest()


def _build(md, out):
    return subprocess.run([sys.executable, os.path.join(SCRIPTS, "build.py"),
                           "--md", md, "--out", out],
                          capture_output=True, text=True)


def _only_html(d):
    hs = [f for f in os.listdir(d) if f.endswith(".html")]
    return os.path.join(d, hs[0]) if hs else None


def _qa(html):
    return subprocess.run([sys.executable, os.path.join(SCRIPTS, "qa_html.py"), html],
                          capture_output=True, text=True)


def _edit(work, pairs, fails, title):
    """把 (old, new) 逐對套進樣張目錄底下所有 .md／.csv；每一對都要剛好命中一次。"""
    for old, new in pairs:
        hit = 0
        for root, _dirs, files in os.walk(work):
            for fn in files:
                if not fn.endswith((".md", ".csv")):
                    continue
                p = os.path.join(root, fn)
                t = io.open(p, encoding="utf-8").read()
                if old in t:
                    hit += t.count(old)
                    io.open(p, "w", encoding="utf-8").write(t.replace(old, new, 1))
        if hit != 1:
            fails.append(f"{title}: 要改的那一段命中 {hit} 次（應為 1）：{old[:40]!r}")
            return False
    return True


def main():
    tmp = tempfile.mkdtemp(prefix="rhtmlb-test-")
    fails = []

    print("=== A 回歸：六個舊樣張的 HTML md5 要逐 byte 相同 ===")
    for name, want in BASELINE.items():
        md = os.path.join(ROOT, "examples", name, "報告內容.md")
        od = os.path.join(tmp, name)
        r = _build(md, od)
        if r.returncode != 0:
            fails.append(f"{name}: build 失敗\n{r.stdout}{r.stderr}")
            print(f"  [FAIL] {name:<16} build 失敗")
            continue
        got = _md5(_only_html(od))
        ok = got == want
        print(f"  [{'OK  ' if ok else 'FAIL'}] {name:<16} {got}"
              + ("" if ok else f"  ≠ {want}"))
        if not ok:
            fails.append(f"{name}: md5 {got} ≠ 定版 {want}（預設行為被改掉了）")

    print("=== A 回歸：JS／CSS 逐字元不變、themes.py 檔案零變動 ===")
    any_html = None
    for name in BASELINE:
        od = os.path.join(tmp, name)
        if os.path.isdir(od) and _only_html(od):
            any_html = _only_html(od)
            break
    if any_html:
        h = io.open(any_html, encoding="utf-8").read()
        js = re.findall(r"<script[^>]*>(.*?)</script>", h, re.S)
        cs = re.findall(r"<style[^>]*>(.*?)</style>", h, re.S)
        for what, blocks, want in (("JS ", js, JS_MD5), ("CSS", cs, CSS_MD5)):
            got = hashlib.md5(blocks[0].encode("utf-8")).hexdigest() if blocks else "（找不到）"
            ok = got == want
            print(f"  [{'OK  ' if ok else 'FAIL'}] {what}              {got}")
            if not ok:
                fails.append(f"{what} md5 {got} ≠ 定版 {want}")
    got = _md5(os.path.join(SCRIPTS, "themes.py"))
    ok = got == THEMES_MD5
    print(f"  [{'OK  ' if ok else 'FAIL'}] themes.py       {got}")
    if not ok:
        fails.append(f"themes.py md5 {got} ≠ {THEMES_MD5}（v1.6 不該動這個檔）")

    print(f"=== A 回歸：兩個 v1.6 新樣張 build ＋ qa {QA_ITEMS} 項全綠 ===")
    newdemo = {}
    for name in ("charts-demo-6", "sig-shade-demo"):
        md = os.path.join(ROOT, "examples", name, "報告內容.md")
        od = os.path.join(tmp, name)
        r = _build(md, od)
        if r.returncode != 0:
            fails.append(f"{name} build 失敗\n{r.stdout}{r.stderr}")
            print(f"  [FAIL] {name:<16} build")
            continue
        html = _only_html(od)
        newdemo[name] = io.open(html, encoding="utf-8").read()
        q = _qa(html)
        nitem = len(re.findall(r"^\s*\[(?:OK  |BAD )\]", q.stdout, re.M))
        ok = "總結：全部通過" in q.stdout and nitem == QA_ITEMS
        print(f"  [{'OK  ' if ok else 'FAIL'}] {name:<16} build ＋ qa {nitem} 項全綠")
        if not ok:
            fails.append(f"{name} qa 沒有全綠或項數不是 {QA_ITEMS}（{nitem}）\n" + q.stdout)

    body = newdemo.get("charts-demo-6", "")
    n_icon = body.count('d="M12 2.6 23 21.4H1z"')
    n_sig = body.count('data-sig="1"')
    n_lv = body.count("data-sig-lv=")
    ok = n_icon == 3 and n_sig == 3 and n_lv == 0
    print(f"  [{'OK  ' if ok else 'FAIL'}] charts-demo-6    圖內 warn icon 2 ＋正文 1 ＝{n_icon}；"
          f"顯著格 {n_sig}（3 組各只標 1 格）；沒有深淺階 {n_lv}")
    if not ok:
        fails.append(f"charts-demo-6 icon={n_icon}（要 3）／sig={n_sig}（要 3）／lv={n_lv}（要 0）")

    body = newdemo.get("sig-shade-demo", "")
    lv = [body.count('data-sig-lv="%d"' % i) for i in (1, 2, 3)]
    ncell = body.count('data-sig="1"')
    # 兩張表共 5 組配對 × 每組 2 格（沒宣告 mark ＝兩格都標）＝10 格；
    # 強度值 5.91/3.04/2.12（lr 表）與 3.12/6.41（tb 表）→ 第 1 階 2 格、第 2 階 4 格、第 3 階 4 格
    ok = lv == [2, 4, 4] and ncell == 10 and "此格為" not in body
    print(f"  [{'OK  ' if ok else 'FAIL'}] sig-shade-demo   三階格數 第1階{lv[0]}／第2階{lv[1]}／第3階{lv[2]}"
          f"；沒宣告 mark 時兩格都標（共 {ncell} 格）")
    if not ok:
        fails.append(f"sig-shade-demo 三階分布 {lv}（要 [2,4,4]）／sig 格 {ncell}（要 10）")

    print("=== B 組合：mark: max（標哪一格）＋ v／levels（多深）要能併用 ===")
    work = os.path.join(tmp, "combo")
    shutil.copytree(os.path.join(ROOT, "examples", "charts-demo-6"), work)
    if _edit(work, [COMBO], fails, "併用組合"):
        od = os.path.join(work, "out")
        r = _build(os.path.join(work, "報告內容.md"), od)
        if r.returncode != 0:
            fails.append("併用組合 build 失敗\n" + r.stdout + r.stderr)
            print("  [FAIL] build")
        else:
            h = io.open(_only_html(od), encoding="utf-8").read()
            cells = re.findall(r'data-sig="1"(?: data-sig-lv="(\d)")?[^>]*?title="([^"]*)"', h)
            lvs = [c[0] for c in cells]
            # 3 組配對各只標 1 格（mark: max），三格的深淺分別是 3／1／2（依 v）
            ok1 = lvs == ["3", "1", "2"]
            print(f"  [{'OK  ' if ok1 else 'FAIL'}] 只標較大格 {len(cells)} 個、深淺依 v＝{lvs}（要 ['3','1','2']）")
            if not ok1:
                fails.append(f"併用：格數/階數 {lvs} ≠ ['3','1','2']")
            # tooltip 要兩件事都講到，而且不重複「經統計檢定有顯著差異」
            tip = cells[0][1] if cells else ""
            ok2 = ("配對中數值較大的一格" in tip and "第 3 階／共 3 階" in tip
                   and tip.count("經統計檢定有顯著差異") == 1)
            print(f"  [{'OK  ' if ok2 else 'FAIL'}] tooltip 同時講「哪一格」與「多深」且不重複")
            if not ok2:
                fails.append("併用 tooltip 不對：" + tip)
            # 引擎自動補的備註句：mark 那句 ＋ 深淺那句，接在一起、不互相蓋掉
            note = [re.sub(r"<[^>]+>", "", m) for m in
                    re.findall(r'<p class="blk-note">(.*?)</p>', h, re.S) if "底色" in m]
            n = note[0] if note else ""
            ok3 = ("配對中只標數值較大的一格" in n and "底色深淺＝|t|" in n
                   and n.count("底色著色為經統計檢定有顯著差異") == 1
                   and "方向為左右著色" not in n)
            print(f"  [{'OK  ' if ok3 else 'FAIL'}] 備註句 mark ＋ 深淺兩句疊加、沒有重複或矛盾")
            if not ok3:
                fails.append("併用備註句不對：" + n)

    print(f"=== C 負向（{len(NEG)} 條）：宣告寫錯要報對的錯 ＋ 行號 ＋ exit 1 ＋ 不產 HTML ===")
    for i, (title, ex, pairs, want) in enumerate(NEG, 1):
        work = os.path.join(tmp, "neg", str(i))
        shutil.copytree(os.path.join(ROOT, "examples", ex), work)
        if not _edit(work, pairs, fails, title):
            print(f"  [FAIL] {i:2d} {title} — 找不到要改的那一段")
            continue
        od = os.path.join(work, "out")
        r = _build(os.path.join(work, "報告內容.md"), od)
        msg = r.stdout + r.stderr
        wrote = os.path.isdir(od) and any(f.endswith(".html") for f in os.listdir(od))
        lined = bool(re.search(r"第 \d+ 行", msg))
        ok = r.returncode == 1 and want in msg and lined and not wrote
        print(f"  [{'OK  ' if ok else 'FAIL'}] {i:2d} {title}")
        if not ok:
            fails.append(f"{title}: exit={r.returncode} 產檔={wrote} 有行號={lined} "
                         f"訊息含 {want!r}={want in msg}\n{msg[:600]}")

    shutil.rmtree(tmp, ignore_errors=True)
    print()
    if fails:
        print(f"[{len(fails)} FAIL]")
        for f in fails:
            print(" -", f)
        return 1
    print("[ALL PASS]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
